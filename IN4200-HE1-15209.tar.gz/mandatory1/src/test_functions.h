#ifndef TEST_FUNCTIONS_H
#define TEST_FUNCTIONS_H

void test_read_graph_from_file1();
void test_read_graph_from_file2();
void test_count_mutual_links1();
void test_count_mutual_links1_OMP();
void test_count_mutual_links2();
void test_count_mutual_links2_OMP();

#endif
